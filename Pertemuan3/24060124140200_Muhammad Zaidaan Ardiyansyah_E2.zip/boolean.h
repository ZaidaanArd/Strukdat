#ifndef BOOLEAN_H
#define BOOLEAN_H

typedef enum
{
    FALSE,
    TRUE
} boolean;

#endif